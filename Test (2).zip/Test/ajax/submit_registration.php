<?php
require_once '../controller/StudentController.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];
    $course = $_POST['course'];
    $grade = $_POST['grade'];
    $contact = $_POST['contact'];
    $comments = $_POST['comments'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

  
    $target_dir = "../uploads/"; 
    $image = $_FILES['image']['name']; 
    $target_file = $target_dir . basename($image); 
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    $check = getimagesize($_FILES['image']['tmp_name']);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    if ($_FILES["image"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
           
            $controller = new StudentController();
            $response = $controller->registerStudent($name, $email, $age, $course, $grade, $contact, $comments, $password, $target_file); // Pass the image path to the controller

            echo $response;
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        echo "Sorry, your file was not uploaded.";
    }

    $controller = new StudentController();
    $response = $controller->registerStudent($name, $email, $age, $course, $grade, $contact, $comments, $password , null);
    
    echo $response;
}
?>
