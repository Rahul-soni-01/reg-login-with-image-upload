<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Reg. Form</title>
</head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="assets/js/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<body>
<link rel="stylesheet" href="css/style.css">
<div class="container">
	<div class="form-wrap">	
        <a href="/Test/view/login.php" class="btn btn-primary">Login</a>
	<form id="registration-form" method="post" enctype="multipart/form-data" >
     <div class="row">
          <div class="col-md-6">
               <div class="form-group">
                    <label id="name-label" for="name">Student Name</label>
                    <input type="text" name="name" id="name" placeholder="Enter your full name" class="form-control" required>
               </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
                <label id="image-label" for="image">Upload Image</label>
                <input type="file" name="image" id="image" class="form-control" required>
            </div>
        </div>
     </div>
     <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label id="email-label" for="email">Student Email</label>
                <input type="email" name="email" id="email" placeholder="Enter your email" class="form-control" required>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label id="Password-label" for="Password">Student Password</label>
                <input type="password" name="password" id="Password" placeholder="Enter your Password" class="form-control" required>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label id="number-label" for="age">Age</label>
                <input type="number" name="age" id="age" min="10" max="99" class="form-control" placeholder="Enter your age" required>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="course">Course</label>
                <input type="text" name="course" id="course" class="form-control" placeholder="Enter your course" required>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="grade">Grade/Year Level</label>
                <input type="text" name="grade" id="grade" class="form-control" placeholder="Enter your grade/year level" required>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="contact">Contact Number</label>
                <input type="tel" name="contact" id="contact" class="form-control" placeholder="Enter your contact number" required>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label>Additional Comments</label>
                <textarea id="comments" class="form-control" name="comments" placeholder="Any additional information..."></textarea>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-4">
            <button type="submit" id="submit" class="btn btn-success btn-block">Register</button>
        </div>
    </div>
</form>

	</div>	
</div>
</body>
</html>