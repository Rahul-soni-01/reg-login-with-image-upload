<?php
session_start();
require_once '../controller/StudentController.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); 
    exit();
}

echo "<h1>Welcome to the Dashboard!</h1>";
echo "<p>Your user ID is: " . $_SESSION['user_id'] . "</p>";
echo "<p>Your name is: " . $_SESSION['user_name'] . "</p>";
echo "<p>Your email is: " . $_SESSION['user_email'] . "</p>";

echo '<a href="profile.php" class="btn btn-danger">Profile</a> </br>';

echo '<a href="logout.php" class="btn btn-danger">Logout</a>';

$user_id = $_SESSION['user_id'];

$controller = new StudentController();
$userData = $controller->getStudentById($user_id);

if (!$userData) {
    echo "User not found.";
    exit();
}

$image_path = $userData['image_path'];

if (!empty($image_path)) { ?>
    <img src="<?php echo $image_path; ?>" alt="Profile Picture" style="width:150px;height:150px;">
<?php } else { ?>
    <p>No profile picture available.</p>
<?php } 
?>
