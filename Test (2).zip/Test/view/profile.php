<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");  
    exit();
}

require_once '../controller/StudentController.php';

$controller = new StudentController();
$user = $controller->getStudentById($_SESSION['user_id']); 
$successMessage = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $course = $_POST['course'];
    $grade = $_POST['grade'];
    $contact = $_POST['contact'];
    $comments = $_POST['comments'];
    
    $updated = $controller->updateStudentProfile($_SESSION['user_id'], $name, $age, $course,$grade,$contact,$comments);

    if ($updated) {
        echo "Profile updated successfully!";
        $_SESSION['user_name'] = $name;
      
    } else {
        echo "Failed to update profile.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script>
        // JavaScript to hide the success message after 5 seconds
        function hideMessage() {
            setTimeout(function() {
                document.getElementById('success-message').style.display = 'none';
            }, 5000);
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Edit Profile</h2>

        <?php if ($successMessage): ?>
            <div id="success-message" class="alert alert-success">
                <?php echo $successMessage; ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="profile.php">
            
            <div class="row">
          <div class="col-md-12">
               <div class="form-group">
                    <label id="name-label" for="name">Student Name</label>
                    <input type="text" name="name" id="name" value="<?php echo $user['name']; ?>" placeholder="Enter your full name" class="form-control" required>
               </div>
          </div>
     </div>
     <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label id="email-label" for="email">Student Email</label>
                <input type="email" name="email" id="email" value="<?php echo $user['email']; ?>" placeholder="Enter your email" class="form-control" disabled>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label id="Password-label" for="Password">Student Password</label>
                <input type="password" name="password" id="Password" value="<?php echo $user['password']; ?>" placeholder="Enter your Password" class="form-control" disabled>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label id="number-label" for="age">Age</label>
                <input type="number" name="age" id="age" value="<?php echo $user['age']; ?>" min="10" max="99" class="form-control" placeholder="Enter your age" required>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="course">Course</label>
                <input type="text" name="course" id="course" value="<?php echo $user['course']; ?>" class="form-control" placeholder="Enter your course" required>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="grade">Grade/Year Level</label>
                <input type="text" name="grade" id="grade" value="<?php echo $user['grade']; ?>" class="form-control" placeholder="Enter your grade/year level" required>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="contact">Contact Number</label>
                <input type="tel" name="contact" id="contact" value="<?php echo $user['contact']; ?>" class="form-control" placeholder="Enter your contact number" required>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label>Additional Comments</label>
                <textarea id="comments" class="form-control" name="comments" placeholder="Any additional information..."><?php echo $user['comments']; ?>"</textarea>
            </div>
        </div>
    </div>
            <button type="submit" class="btn btn-primary">Update Profile</button>
        </form>
        <br>
        <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</body>
</html>
