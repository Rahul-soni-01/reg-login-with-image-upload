<?php
include 'view/registration_form.php';
